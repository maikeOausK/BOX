#!/bin/bash
gnuplot <<- EOF
  set size 1, 0.55
  set origin 0, 0.4
  set term postscript eps 
  set term post landscape color "Times-Roman" 24
  set output 'Fit_c.eps'
  set multiplot layout 1,2 rowsfirst
  set macros
#
  set xrange [3.5:10.5]
  set xtics 4,1,10
  set logscale y
  set yrange [0.2:1.1]
  set ytics add 0.2
  set xlabel "N"
  set ylabel "F"
  set format y "%g"
  

  set key samplen 3
  set key at 15,0.7 Left width -2.8
  set key spacing 1


  set fit logfile 'Fit_N_var_O_V_6_c.log'

  f(x) = a*exp(-b*(x-2))
  fit f(x) 'Fid_dis_N_var_O_V_6.944.txt' using 1:2 via a,b
  
  set fit logfile 'Fit_iso_var_O_V_6_c.log'
  g(x) = c*exp(-d*(x-2))
  fit g(x) 'Fid_dis_isoN_var_O_V_6.944.txt' using 1:2 via c,d

  set fit logfile 'Fit_noniso_var_O_V_6_c.log'
  h(x) = e*exp(-z*(x-2))
  fit h(x) 'Fid_dis_nonisoN_var_O_V_6.944.txt' using 1:2 via e,z


  set fit logfile 'Fit_N_var_O_V_15_c.log'

  i(x) = r*exp(-s*(x-2))
  fit i(x) 'Fid_dis_N_var_O_V_15.52.txt' using 1:2 via r,s
  
  set fit logfile 'Fit_iso_var_O_V_15_c.log'
  j(x) = t*exp(-u*(x-2))
  fit j(x) 'Fid_dis_isoN_var_O_V_15.52.txt' using 1:2 via t,u

  set fit logfile 'Fit_noniso_var_O_V_15_c.log'
  k(x) = v*exp(-w*(x-2))
  fit k(x) 'Fid_dis_nonisoN_var_O_V_15.52.txt' using 1:2 via v,w






# Macros:
  TMARGIN = "set tmargin at screen 0.9; set bmargin at screen 0.55"
  BMARGIN = "set tmargin at screen 0.54; set bmargin at screen 0.18"
  LMARGIN = "set lmargin at screen 0.13; set rmargin at screen 0.52"
  RMARGIN = "set lmargin at screen 0.58; set rmargin at screen 0.97"
#
# No tics
  NOYTICS = "set format y ''; unset ylabel"
  YTICS = "set format y '%g'; set ylabel 'F'"
  XTICS = "set format x '%g'; set xlabel 'N'"
  NOXTICS = "set format x ''; unset xlabel"
#
##
  @TMARGIN; @LMARGIN
 # @YTICS 
  set ytics ( 0.2,"" 0.3, "" 0.4, 0.5,"" 0.6, "" 0.7, "" 0.8, "" 0.9 ,1)
  set label 1 'Va_0/{/Symbol W} = 6.9' at graph 0.02,0.15
  set label 4 'a' at graph 0.9,0.1

#
  plot    f(x) title "" lt rgb "magenta",\
   g(x) title "" lt rgb "cyan" lw 3,\
   h(x) title "" lt rgb "green" lw 3,\
  'Fid_dis_N_var_O_V_6.944.txt' using 1:2  title "no dis" pointtype 2 lt rgb "red" lw 3 ,\
  'Fid_dis_isoN_var_O_V_6.944.txt' using 1:2  title "iso" pointtype 5 dt'.' lt rgb "blue" lw 3,\
  'Fid_dis_nonisoN_var_O_V_6.944.txt' using 1:2  title "aniso" pointtype 13 pointsize 1.3 dt'-' lt rgb "dark-green" 
#
#
##
  @TMARGIN; @RMARGIN 
  @NOYTICS
  set label 4 'b' at graph 0.9,0.1
  set label 1 'V_0/{/Symbol W} = 15.5' at graph 0.02,0.15

  plot   i(x)   lt rgb "magenta",\
  j(x)  lt rgb "cyan" lw 3,\
  k(x)  lt rgb "green" lw 3,\
 'Fid_dis_N_var_O_V_15.52.txt' using 1:2  title "no dis" pointtype 2 lt rgb "red" lw 3 ,\
 'Fid_dis_isoN_var_O_V_15.52.txt' using 1:2  title "iso" pointtype 5 dt'.' lt rgb "blue" lw 3,\
 'Fid_dis_nonisoN_var_O_V_15.52.txt' using 1:2  title "aniso" pointtype 13 pointsize 1.3 dt'' lt rgb "dark-green" lw 3

  unset multiplot
EOF




