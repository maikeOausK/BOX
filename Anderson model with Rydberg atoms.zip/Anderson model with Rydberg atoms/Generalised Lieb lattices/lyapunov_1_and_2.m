clear

% parameters
Wvec=linspace(0.1,1,100); % disorder width
E=sqrt(0); % energy
maxit=20000; % maximum number of iterations
itreorth=10; % re-orthogonalisation step
 
lambda1=zeros(1,length(Wvec));
lambda12=zeros(1,length(Wvec));

for Wind=1:1:length(Wvec)
    templogvolume=0;
    temploglength=0;
    % intitial vectors + orthonormalisation
    v=[rand-1/2;rand-1/2; rand-1/2; rand-1/2];
    v=v/sqrt(v'*v);
    w=[rand-1/2; rand-1/2; rand-1/2; rand-1/2];
    w=w-(v'*w)*v;
    w=w/sqrt(w'*w);

    X=[v,w];
    
    W=Wvec(Wind);
    for count=1:1:maxit
        X=Tmatrix(W*(rand-1/2),W*(rand-1/2),W*(rand-1/2),W*(rand-1/2),W*(rand-1/2),E)*X;
        
        if mod(count,itreorth)==0
           v=X(:,1);
           w=X(:,2);
           % calculate volume;
           a=norm(v);
           b=norm(w-(v'*w)*v/a^2);
           tempvolume=a*b;
           templogvolume=templogvolume+log(tempvolume);
           temploglength=temploglength+log(a);
           
           % re-orthogonalise
           v=v/sqrt(v'*v);
           w=w-(v'*w)*v;
           w=w/sqrt(w'*w);
           X=[v,w];
        end
    
    end
    % calculate volume;
    a=norm(v);
    b=norm(w-(v'*w)*v/a^2);
    lambda1(Wind)=(log(a)+temploglength)/maxit;
    lambda12(Wind)=(log(a*b)+templogvolume)/maxit;
end

%%
figure(1)
loglog(Wvec,1./lambda1,'r.-',Wvec,1./(lambda12-lambda1),'b.-')
hold on
xlabel('W');
ylabel('\xi_1, \xi_2')
set(gca,'FontSize',20)

%% fitting
f1=fit(log(Wvec)',-log(lambda1)','poly1');
f2=fit(log(Wvec)',-log(lambda12-lambda1)','poly1');

f1.p1
f2.p1

%hold on
%loglog(Wvec,0.25*Wvec.^(2/3))

