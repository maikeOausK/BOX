clear

% parameters
Wvec=linspace(0.1,1,50); % disorder width
Evec=linspace(-3,3,300); % energy
maxit=30000; % maximum number of iterations
itreorth=10; % re-orthogonalisation step
 
lambda1=zeros(length(Wvec),length(Evec));
lambda12=zeros(length(Wvec),length(Evec));

for Eind=1:1:length(Evec)
    E=Evec(Eind)
    for Wind=1:1:length(Wvec)
        templogvolume=0;
        temploglength=0;
        % intitial vectors + orthonormalisation
        v=[rand-1/2;rand-1/2; rand-1/2; rand-1/2];
        v=v/sqrt(v'*v);
        w=[rand-1/2; rand-1/2; rand-1/2; rand-1/2];
        w=w-(v'*w)*v;
        w=w/sqrt(w'*w);
        X=[v,w];
        
        W=Wvec(Wind);
        for count=1:1:maxit
            X=Tmatrix(W*(rand-1/2),W*(rand-1/2),W*(rand-1/2),W*(rand-1/2),W*(rand-1/2),E)*X;
            if mod(count,itreorth)==0
                v=X(:,1);
                w=X(:,2);
                % calculate volume;
                a=norm(v);
                b=norm(w-(v'*w)*v/a^2);
                tempvolume=a*b;
                templogvolume=templogvolume+log(tempvolume);
                temploglength=temploglength+log(a);
                
                % re-orthogonalise
                v=v/sqrt(v'*v);
                w=w-(v'*w)*v;
                w=w/sqrt(w'*w);
                X=[v,w];
            end
        end
        % calculate volume;
        a=norm(v);
        b=norm(w-(v'*w)*v/a^2);
        lambda1(Wind,Eind)=(log(a)+temploglength)/maxit;
        lambda12(Wind,Eind)=(log(a*b)+templogvolume)/maxit;
    end
end
%%
figure(1)
subplot(2,1,1)
imagesc(Evec,Wvec,-log(lambda1))
colorbar
subplot(2,1,2)
imagesc(Evec,Wvec,-log(abs(lambda12-lambda1)))
colorbar

