
% Construction of a Matrix product state (MPS)
% The MPS is a ground state of a RK Hamiltonian
% The initial state: |Psi> = |++++...>
%
% The system is treated as an effective 2 state system
% with the states |R> and |+>  
%(it is assumed that the (pi,-) pulse works perfectly and all occupation
% of the |R> state is transferred to the |-> state => the (pi,-) is neglected
% and in the end, the occupation of |R> can be interpreted as the 
% occupation of the |-> state)

% Hamiltonian of the system:
% H = sum_k Omega_k * sigma_y^(k) +sum_k Delta_k * n_k + sum_k,m V_{km} * n_k * n_m

% Omega_k : Rabi frequency of particle k
% Delta_k : Detuning of the rydberg state of particle k
% V_{km}  : interaction potential
% V_km = V_0 * 1/|k-m|^gamma


clear all;
format long;
N = 4;
realisation = 100;
sigma_i = 0.12;
a     = 4.1;      % distance between the atoms
r0     =4.1;
gamma = 6;        % exponent of interaction force
Omega  = 1; % nearest neighbour interaction
R     = 1.0;        % Blockade Radius

% Definition of the states
ryd  = [1;0]; % Rydberg state
up   = [0;1]; % up state

% single particle operators
num     = ryd*ryd'; % number operator n = |R><R|
sigma_y = [0,i;-i,0]; %
one = eye(2);% identity matrix

% many particle state
  
z = 1;


V_0_vec=[ 1.:0.5:100 101.1:5:10000*Omega 10001*Omega:15:4000*Omega ]

fid(length(realisation),length(V_0_vec)) = 0; % Fidelity 
Fidelity(length(V_0_vec)) = 0;
position(N,3) = 0;
integer = 1;  





    
    x = a*(1:N); % position of the atoms
    
    num_op_m=sparse(N*2^N,2^N);  % all N particle number operators n_k are stored in this matrix
    help_vec_n(1:2,1:2*N) = 0;  % helping vector to produce the N particle sigma_y operator
    O_V(1:length(V_0_vec))       = 0;
    
    GS = up;
    % Construction of the many particle GS
    for cnt =1:N-1
              GS = kron(GS,up);  %construction of many particle product state
    end

    % Construction of all number operators n_k
    for cnt = 1:N
            % Construction of number operators     
            for cnt2 = 1:N

                 if cnt2 == cnt
                      help_vec_n(:,2*cnt2-1:2*cnt2) = num;
                      continue
                 end
                 help_vec_n(:,2*cnt2-1:2*cnt2) = one;

            end

            n_k = sparse(help_vec_n(:,2*N-1:2*N));

            for cnt3 = N-1:-1:1

              n_k =sparse(kron(help_vec_n(:,2*cnt3-1:2*cnt3),n_k));

            end
            num_op_m((cnt-1)*2^N+1:cnt*2^N,:) = n_k;
    end
    % Reference state
    ket_z = z_state(N,z,GS,num_op_m);
    
    
    for counter = 1:length(V_0_vec) % Measuring the fidelity
      for nr = 1:realisation
       
        % Rabi frequency for the two transitions
       V_0 = V_0_vec(counter);
        O_V (counter) = V_0/Omega;
      
       

%       % Duration of the pulses
        Omegatime(1,N) = 0;

        for cnt = N:-1:1
        
              if cnt == N
                 Omegatime(cnt) = acos( (1 + abs(z)^2)^(-1/2) );
                 continue
              end
              Omegatime(cnt)= acos( (1 + abs(z)^2 * (cos(Omegatime(cnt+1)))^2 )^(-1/2) );      
              % Omegatime(cnt)= acos(1/ sqrt(1 + abs(z)^2 * (cos(Omegatime(cnt+1)))^2 ) );    
        end


        
        % Detuning Delta
        %Delta = V_0*(R*(R+1)^6 *(Omega/V_0)^2 -(2*R+1)/(R*(R+1)^6));

        Psi= GS;
        Rk = GS;
        z_op = 0 ;
        for cnter = 1:N
              position(cnter,:) = randn(1,3);
        end 
        for k_atom = 1:N

            %Many particle sigma_y_k operator
            help_vec_s(1:2,1:2*N) = 0; %helping vector to produce the N particle sigma_y operator earth like planets


            for cnt2 = 1:N
                 if cnt2 == k_atom
                      help_vec_s(:,2*cnt2-1:2*cnt2) = sigma_y;
                      continue
                 end
                 help_vec_s(:,2*cnt2-1:2*cnt2) = one;

            end

            s_yk = help_vec_s(:,2*N-1:2*N);

            for cnt3 = N-1:-1:1

              s_yk =sparse(kron(help_vec_s(:,2*cnt3-1:2*cnt3),s_yk));

            end

           
            % Interaction Potential
            
            V_int = sparse(2^N,2^N) ;
            Hamil_k = sparse(2^N,2^N);
        
            for cnt = 1:N

                if cnt == k_atom 
                    continue
                end 
               
                 d_kl =  dist(k_atom,cnt,r0,N,sigma_i,position);
                 V_int = sparse(V_int + 0.5*(V_0*a^6 )/(abs(d_kl)^gamma) * ...
                 num_op_m((k_atom-1)*2^N+1:k_atom*2^N,:)*num_op_m((cnt-1)*2^N+1:cnt*2^N,:)); %* num_all others 
                
            end 
         %ket_z = z_state(N,z,GS,num_op_m);
            t = Omegatime(k_atom)/(Omega);
            Hamil_k = sparse(Omega*s_yk + V_int);
            
            Psi = expm(-1i*t*Hamil_k)*Psi;
            
%            % RK reference state 
%            if k_atom == 1
%                    z_op = s_yk*( eye(2^N) - num_op_m(k_atom*2^N+1:(k_atom+1)*2^N,:) );
%                                
%            elseif k_atom == N
%                z_op =( eye(2^N) - num_op_m((k_atom-2)*2^N+1:(k_atom-1)*2^N,:) ) * s_yk;
%         
%            else
%                z_op =( eye(2^N)-num_op_m((k_atom-2)*2^N+1:(k_atom-1)*2^N,:) )...
%                              * s_yk *( eye(2^N) - num_op_m( k_atom*2^N+1:(k_atom+1)*2^N,: ));
%       
%            end
%           
%            Rk = expm(-1i*Omegatime(k_atom)*z_op)*Rk;
        end %k_atom
   
  

         %Rk'*ket_z
        
         fid(nr,counter) = abs(Psi'*ket_z)^2;
      end
     Fidelity(counter) = sum(fid(:,counter));
    integer = integer+1;
end

 figure()
semilogx(O_V,Fidelity(:)/realisation)

fileID = fopen('RK_nonisodis_n4_z_1.txt','w');
fprintf(fileID,'%6.5f %12.11E \n',[O_V;Fidelity(1,:)/realisation]);
fclose(fileID);
 

