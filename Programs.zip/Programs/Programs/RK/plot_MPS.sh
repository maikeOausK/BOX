#!/bin/bash
gnuplot <<- EOF
  set term postscript eps 
  set term post landscape color "Times-Roman" 24
  set output 'MPS.eps'
  set samples 1000 
  set macros

  set ytics  0,0.2,1
  set format y "%g"
  set format x "10^{%T}"
  set logscale x
  set xrange [0.1:10000]
  set yrange [0:1.01]
  set xtics 0.01,10,1000
  set xlabel "V_0/{/Symbol W}"
  set ylabel "F"

  set label 1 '{/Symbol x} = 10' at graph 0.05,0.9
#
 plot 'RK_N2_z10.txt' using 1:2  title "N = 2" w line lt rgb "purple" lw 3,\
 'RK_N3_z10.txt' using 1:2  title "N = 3" w line dt'' lt rgb "red" lw 3,\
 'RK_N4_z10.txt' using 1:2  title "N = 4" w line dt'' lt rgb "blue" lw 3,\
 'RK_N5_z10.txt' using 1:2  title "N = 5" w line dt'' lt rgb "magenta" lw 3,\
 'RK_N6_z10.txt' using 1:2  title "N = 6" w line dt'' lt rgb "cyan" lw 3,\
# 'RK_N7_z10.txt' using 1:2  title "N = 7" w line dt'' lt rgb "dark-green" lw 3


EOF




