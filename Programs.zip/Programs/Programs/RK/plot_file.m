% Read in data and plot it
clear all;
format long;
% 1: Omega/V_0, 2: N = 4, 3: N = 6
fid_RK = dlmread('RK_N7_z10.txt');
fid_RKN3 = dlmread('RK_N3_z10.txt');
isodis7 = dlmread('RK_isodis_n7_z_10.txt');
nisodis7 = dlmread('RK_nonisodis_n7_z_10.txt');

% 
figure()
semilogx(fid_RK(:,1),fid_RK(:,2),'r',fid_RKN3(:,1),fid_RKN3(:,2),'b')