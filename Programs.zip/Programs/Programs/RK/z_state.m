% calculates the actual z_state

% Calculation of the exact RK state

function ket_z = z_state(N,z,GS,num_op_m)
 

  sigma_y = [0,1;0,0]; %
  
 %  Construction of the correct RK state
   Z_z     = ((1+sqrt(1+4*z^2))/2)^N;
   z_state = 1 ;
   
 %  Many particle sigma_y_k operator
  help_vec_s(1:2,1:2*N) = 0; %helping vector to produce the N particle sigma_y operator earth like planets

     
   for cnt = 1:N 
       
       for cnt2 = 1:N
               if cnt2 == cnt
                      help_vec_s(:,2*cnt2-1:2*cnt2) = sigma_y;
                      continue
               end
               help_vec_s(:,2*cnt2-1:2*cnt2) = eye(2);

        end

        s_xk = help_vec_s(:,2*N-1:2*N);

       for cnt3 = N-1:-1:1

            s_xk =sparse(kron(help_vec_s(:,2*cnt3-1:2*cnt3),s_xk));
       end

       if cnt == 1
           z_state = z_state *(eye(2^N)+1*z*s_xk*( eye(2^N) - num_op_m(cnt*2^N+1:(cnt+1)*2^N,:) ));
           continue
       end
       if cnt == N
            z_state =z_state*(eye(2^N)+1*z*( eye(2^N) - num_op_m((cnt-2)*2^N+1:(cnt-1)*2^N,:) ) * s_xk);
           continue
       end
        z_state = z_state *(eye(2^N)+ 1*z*( eye(2^N)-num_op_m((cnt-2)*2^N+1:(cnt-1)*2^N,:) )...
                             * s_xk *( eye(2^N) - num_op_m( cnt*2^N+1:(cnt+1)*2^N,: ) ));
             
   end
        
   %z_state = z_state/sqrt(Z_z);
   ket_z = z_state*GS;
   ket_z = ket_z/norm(ket_z);
end