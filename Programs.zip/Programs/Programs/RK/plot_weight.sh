#!/bin/bash
gnuplot <<- EOF
  set term postscript eps 
  set term post landscape color "Times-Roman" 28
  set output 'weight_RK.eps'
  set ytics  0,0.2,1
  set format y "%g"
  set format x "10^{%T}"
  set logscale x
  set xrange [0.07:1000]
  set xtics 0.01,10,1000

  set xlabel "V_0/{/Symbol W}"
#
  set ytics  0,0.2,1
 
  set samples 1000
  set xlabel "V_0/{/Symbol W}"
  set ylabel "|{/Symbol b}|"
  i = {0.0,1.0}
  plot (128*x*abs(sin(sqrt(16777216-8192*x*x+9*x*x*x*x)*acos(sqrt((1+2*x*x)/(1+3*x*x + x*x*x*x)))/(128*x)) ))/(sqrt(16777216-8192*x*x+9*x*x*x*x)) title "" w lines lt rgb "dark-violet" lw 2
EOF




