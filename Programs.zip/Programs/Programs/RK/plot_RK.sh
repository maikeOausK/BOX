#!/bin/bash
gnuplot <<- EOF
  set term postscript eps 
  set term post landscape color "Times-Roman" 24
  set output 'RKz.eps'
  set samples 1000 
  set macros

  set ytics  0,0.2,1
  set format y "%g"
  set format x "10^{%T}"
  set logscale x
  set xrange [0.07:2000]
  set yrange [0:1.05]
  set xtics 0.01,10,10000
  set xlabel "V_0/{/Symbol W}"
  set ylabel "F"
  set multiplot layout 2,2 rowsfirst
  set key samplen 3

# Macros:
  TMARGIN = "set tmargin at screen 0.95; set bmargin at screen 0.6
  BMARGIN = "set tmargin at screen 0.54; set bmargin at screen 0.18"
  LMARGIN = "set lmargin at screen 0.13; set rmargin at screen 0.52"
  RMARGIN = "set lmargin at screen 0.58; set rmargin at screen 0.97"
# No tics
  NOYTICS = "set format y ''; unset ylabel"
  YTICS = "set format y '%g'; set ylabel 'F'"
  XTICS = "set format x '10^{%T}'; set xlabel 'V_0/{/Symbol W}'"
  NOXTICS = "set format x ''; unset xlabel"

#
#
  @TMARGIN; @LMARGIN
  @YTICS; @NOXTICS 
  set key vertical bottom right
  set ytics  0,0.2,1
  set label 1 'z = 0.1' at graph 0.05,0.7
 set label 2 'a'  at graph 0.05,0.15
 plot  'RK_N2_z01.txt' using 1:2  title "N = 2" w lines lt rgb "red" lw 2,\
 'RK_N3_z01.txt' using 1:2  title "N = 3" w line dt'.' lt rgb "blue" lw 4,\
 'RK_N4_z01.txt' using 1:2  title "N = 4" w line dt'-' lt rgb "dark-green" lw 3,\
 'RK_N5_z01.txt' using 1:2  title "N = 5" w line dt'.-' lt rgb "magenta" lw 3,\
 'RK_N6_z01.txt' using 1:2  title "N = 6" w line dt'-.-' lt rgb "cyan" lw 3,\
 'RK_N7_z01.txt' using 1:2  title "N = 7" w line dt'..-' lt rgb "dark-violet" lw 3

  @TMARGIN; @RMARGIN 
  @NOYTICS
  set label 1 'z = 0.5' at graph 0.75,0.7
  set label 2 'b'  at graph 0.92,0.15
 plot  'RK_N2_z05.txt' using 1:2  title "" w lines lt rgb "red" lw 2,\
 'RK_N3_z05.txt' using 1:2  title "" w line dt'.' lt rgb "blue" lw 4,\
 'RK_N4_z05.txt' using 1:2  title "" w line dt'-' lt rgb "dark-green" lw 3,\
'RK_N5_z05.txt' using 1:2  title "" w line dt'.-' lt rgb "magenta" lw 3,\
 'RK_N6_z05.txt' using 1:2  title "" w line dt'-.-' lt rgb "cyan" lw 3,\
 'RK_N7_z05.txt' using 1:2  title "" w line dt'..-' lt rgb "dark-violet" lw 3
#
  @BMARGIN; @LMARGIN
  @YTICS; @XTICS
  set label 1 'z = 1' at graph 0.05,0.86
  set label 2 'c'  at graph 0.05,0.15
  set arrow from 1,graph(0,0) to 1,graph(1,0.18) nohead lw 2
  set arrow from 1,graph(0,0.38) to 1,graph(1,1) nohead lw 2
  set label 3 ' {/Symbol W}=V_{NN}' at 0.25, 0.3
  set arrow from 64,graph(0,0) to 64,graph(1,0.18) nohead lw 2
  set arrow from 64,graph(0,0.38) to 64,graph(1,1) nohead lw 2
  set label 4 '{/Symbol W}=V_{NNN}' at 20, 0.3

  set xtics 0.01,10,10000
  plot 'RK_N2_z1.txt' using 1:2  title "" w lines lt rgb "red" lw 2,\
'RK_N3_z1.txt' using 1:2  title "" w line dt'.' lt rgb "blue" lw 4,\
 'RK_N4_z1.txt' using 1:2  title "" w line dt'-' lt rgb "dark-green" lw 3,\
 'RK_N5_z1.txt' using 1:2  title "" w line dt'.-' lt rgb "magenta" lw 3,\
 'RK_N6_z1.txt' using 1:2  title "" w line dt'-.-' lt rgb "cyan" lw 3,\
'RK_N7_z1.txt' using 1:2  title "" w line dt'..-' lt rgb "dark-violet" lw 3

  unset label 3
  unset label 4
  unset arrow
  @BMARGIN; @RMARGIN
  @NOYTICS


  set label 1 'z = 10' at graph 0.75,0.86
#
  set label 2 'd'  at graph 0.9,0.15
 plot 'RK_N2_z10.txt' using 1:2  title "" w lines lt rgb "red" lw 2,\
 'RK_N3_z10.txt' using 1:2  title "" w line dt'.' lt rgb "blue" lw 4,\
 'RK_N4_z10.txt' using 1:2  title "" w line dt'-' lt rgb "dark-green" lw 3,\
 'RK_N5_z10.txt' using 1:2  title "" w line dt'.-' lt rgb "magenta" lw 3,\
'RK_N6_z10.txt' using 1:2  title "" w line dt'-.-' lt rgb "cyan" lw 3,\
 'RK_N7_z10.txt' using 1:2  title "" w line dt'..-' lt rgb "dark-violet" lw 3,\

EOF




