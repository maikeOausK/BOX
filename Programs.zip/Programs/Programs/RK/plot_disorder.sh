gnuplot <<- EOF
  set term postscript eps enhanced
  set term post landscape color "Times-Roman" 24
  set output 'RKdis.eps'
  set samples 1000 
  set macros

  set ytics  0,0.2,1
  set format y "%g"
  set format x "10^{%T}"
  set xrange  [0.7:1000]
  set xtics 0.0001,10,1000
  set xlabel "V_0/{/Symbol W}"
  set multiplot layout 2,2 rowsfirst

# Macros:
  TMARGIN = "set tmargin at screen 0.95; set bmargin at screen 0.6" #t: oben dach  b: y oben
  BMARGIN = "set tmargin at screen 0.54; set bmargin at screen 0.18" #t unten dach #b: y unten
  LMARGIN = "set lmargin at screen 0.13; set rmargin at screen 0.52"
  RMARGIN = "set lmargin at screen 0.58; set rmargin at screen 0.97"
# No tics
  NOYTICS = "set format y ''; unset ylabel"
  YTICS = "set format y '%g'; set ylabel 'F'"
  XTICS = "set format x '10^{%T}'; set xlabel 'V_0/{/Symbol W}'"
  NOXTICS = "set format x ''; unset xlabel"

  set key at 25,0.6 Left width - 2.8
  set key spacing 1.25
  set key samplen 3


  set logscale x  
  @TMARGIN; @LMARGIN
  @YTICS; @NOXTICS 
  set ytics  0,0.2,1
  set yrange [0:1.05]
  set label 2 'z = 1' at graph 0.5,0.3
  set label 3 'N = 4' at graph 0.5,0.1
  set label 1 'a' at graph 0.9,0.1
  plot 'RK_N4_z1.txt' using 1:2  title "no dis" w lines lt rgb "red" lw 2,\
 'RK_isodis_n4_z_1.txt' using 1:2  title "iso" w line dt'.'  lt rgb "blue" lw 3,\
 'RK_nonisodis_n4_z_1.txt' using 1:2  title "aniso" w line dt'-'  lt rgb "dark-green" lw 3

  set arrow from 1,graph(0,0) to 1,graph(1,0.58) nohead lw 2
  set arrow from 1,graph(0,0.78) to 1,graph(1,1) nohead lw 2
  set label 4 ' {/Symbol W}=V_{NN}' at 0.65, 0.7

  set arrow from 64,graph(0,0) to 64,graph(1,0.58) nohead lw 2
  set arrow from 64,graph(0,0.78) to 64,graph(1,1) nohead lw 2
  set label 5 '{/Symbol W}=V_{NNN}' at 20, 0.7


  @TMARGIN; @RMARGIN 
  @NOYTICS; 
  set label 2 'z = 1' at graph 0.4,0.3
  set label 3 'N = 7' at graph 0.4,0.1
  set label 1 'b' at graph 0.9,0.1
  plot 'RK_N7_z1.txt' using 1:2  title "" w lines lt rgb "red" lw 2,\
 'RK_isodis_n7_z_1.txt' using 1:2  title "" w line dt'.'  lt rgb "blue" lw 3,\
 'RK_nonisodis_n7_z_1.txt' using 1:2  title "" w line dt'-'  lt rgb "dark-green" lw 3


 unset arrow
 unset label 5
 unset label 4



  @BMARGIN; @LMARGIN
  @YTICS; @XTICS
  
  set label 3 'N = 4' at graph 0.5,0.1
   set label 2 'z = 10' at graph 0.5,0.3
  set label 1 'c' at graph 0.9,0.1
  plot 'RK_N4_z10.txt' using 1:2  title "" w lines lt rgb "red" lw 2,\
 'RK_isodis_n4_z_10.txt' using 1:2  title "" w line dt'.'  lt rgb "blue" lw 3,\
 'RK_nonisodis_n4_z_10.txt' using 1:2  title "" w line dt'-'  lt rgb "dark-green" lw 3


 @BMARGIN; @RMARGIN
  @NOYTICS
  set label 2 'z = 10' at graph 0.4,0.3
  set label 3 'N = 7' at graph 0.4,0.1
  set label 1 'd' at graph 0.9,0.1
  plot 'RK_N7_z10.txt' using 1:2  title "" w lines lt rgb "red" lw 2,\
 'RK_isodis_n7_z_10.txt' using 1:2  title "" w line dt'.'  lt rgb "blue" lw 3,\
 'RK_nonisodis_n7_z_10.txt' using 1:2  title "" w line dt'-'  lt rgb "dark-green" lw 3
EOF



