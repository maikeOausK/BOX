#!/bin/bash
gnuplot <<- EOF
  set term postscript eps 
  set term post landscape color "Times-Roman" 28
  set yrange [0:1.05]
  set format x "10^{%T}"
  set logscale x
  set samples 1600
  set xrange [0.07:10000]
   set xtics 0.01,10,1000
  set output 'coeffN2.eps'
  set xlabel "V_0/{/Symbol W}"
  set ylabel "F"
  i = {0.0,1.0}
  set multiplot layout 2,2 rowsfirst
  set key samplen 3
  set macros
  set key at 7000,0.93


# Macros:
  TMARGIN = "set tmargin at screen 0.90; set bmargin at screen 0.55"
  BMARGIN = "set tmargin at screen 0.55; set bmargin at screen 0.20"
  LMARGIN = "set lmargin at screen 0.15; set rmargin at screen 0.55"
  RMARGIN = "set lmargin at screen 0.55; set rmargin at screen 0.95"
# No tics
  NOYTICS = "set format y ''; unset ylabel"
  YTICS = "set format y '%g'; set ylabel 'F'"
  XTICS = "set format x '10^{%T}'; set xlabel 'V_0/{/Symbol W}'"
  NOXTICS = "set format x ''; unset xlabel"


  @TMARGIN; @LMARGIN
  @YTICS; @NOXTICS
  set label 1 'z = 0.1' at graph 0.05,0.8
  set label 2 'a'  at graph 0.05,0.17
  z = 0.1
  plot   'RK_N2_z01.txt' using 1:2  title "F" w lines lt rgb "red" lw 2,\
   0.5*abs((((-1+exp(0.5*i*sqrt(16+x*x)*atan(z)))*x+(1+exp(0.5*i*sqrt(16+x*x)*atan(z)))*sqrt(16+x*x))*z)/(sqrt(16+x*x)*(z+i*sqrt(1+z*z)))) title "|{/Symbol d}|" w line dt'-' lt rgb "blue" lw 3

  @TMARGIN; @RMARGIN 
  @NOYTICS
  set label 1 'z = 0.5' at graph 0.05,0.8
  set label 2 'b'  at graph 0.92,0.17  
  z = 0.5
  plot   'RK_N2_z05.txt' using 1:2  title "" w lines lt rgb "red" lw 2,\
   0.5*abs((((-1+exp(0.5*i*sqrt(16+x*x)*atan(z)))*x+(1+exp(0.5*i*sqrt(16+x*x)*atan(z)))*sqrt(16+x*x))*z)/(sqrt(16+x*x)*(z+i*sqrt(1+z*z)))) title "" w line dt'-' lt rgb "blue" lw 3

  @BMARGIN; @LMARGIN
  @YTICS; @XTICS
   set ytics  0,0.2,0.8
  set label 1 'z = 1' at graph 0.05,0.85
  set label 2 'c'  at graph 0.05,0.17
  z = 1
  plot   'RK_N2_z1.txt' using 1:2  title "" w lines lt rgb "red" lw 2,\
   0.5*abs((((-1+exp(0.5*i*sqrt(16+x*x)*atan(z)))*x+(1+exp(0.5*i*sqrt(16+x*x)*atan(z)))*sqrt(16+x*x))*z)/(sqrt(16+x*x)*(z+i*sqrt(1+z*z)))) title "" w line dt'-' lt rgb "blue" lw 3

  @BMARGIN; @RMARGIN
  @NOYTICS
  z = 10
  set label 1 'z = 10' at graph 0.05,0.85
   set label 2 'd'  at graph 0.9,0.17

  plot   'RK_N2_z10.txt' using 1:2  title "" w lines lt rgb "red" lw 2,\
  0.5*abs((((-1+exp(0.5*i*sqrt(16+x*x)*atan(z)))*x+(1+exp(0.5*i*sqrt(16+x*x)*atan(z)))*sqrt(16+x*x))*z)/(sqrt(16+x*x)*(z+i*sqrt(1+z*z)))) title "" w line dt'-' lt rgb "blue" lw 3

EOF




