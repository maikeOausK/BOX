gnuplot <<- EOF
  set term postscript eps 
  set term post landscape color "Times-Roman" 24
  set output 'RKnonisodis.eps'
  set samples 1000 
  set macros

  set ytics  0,0.2,1
  set format y "%g"
  set format x "10^{%T}"

  set label 4 at graph 0.1,0.9 point pointtype 7 pointsize 1 lc rgb 'red'
  set label 5 at graph 0.1,0.76 point pointtype 7 pointsize 2.5 lc rgb 'blue'
  set label 6 at graph 0.1,0.742 point pointtype 7 pointsize 2.5 lc rgb 'blue'
  set label 7 at graph 0.1,0.772 point pointtype 7 pointsize 2.5 lc rgb 'blue'



  set logscale x
  set xrange [1:1000]
  set xtics 0.0001,10,100
  set xlabel "V_0/{/Symbol W}"
  set multiplot layout 2,2 rowsfirst
# Macros:
  TMARGIN = "set tmargin at screen 0.90; set bmargin at screen 0.55"
  BMARGIN = "set tmargin at screen 0.55; set bmargin at screen 0.20"
  LMARGIN = "set lmargin at screen 0.15; set rmargin at screen 0.55"
  RMARGIN = "set lmargin at screen 0.55; set rmargin at screen 0.95"
# No tics
  NOYTICS = "set format y ''; unset ylabel"
  YTICS = "set format y '%g'; set ylabel 'F'"
  XTICS = "set format x '10^{%T}'; set xlabel 'V_0/{/Symbol W}'"
  NOXTICS = "set format x ''; unset xlabel"

  

  @TMARGIN; @LMARGIN
 @YTICS; @NOXTICS 
  set key vertical top left
   set label 2 'z = 1' at graph 0.05,0.4
  set label 1 'N = 4' at graph 0.05,0.2
  plot 'RK_N4_z1.txt' using 1:2  title " " w lines lt rgb "red" lw 2,\
 'RK_isodis_n4_z_1.txt' using 1:2  title " " w line dt'.'  lt rgb "blue" lw 3

  @TMARGIN; @RMARGIN 
  @NOYTICS; 
  set label 1 'N = 7' at graph 0.05,0.2
  plot 'RK_N7_z1.txt' using 1:2  title " " w lines lt rgb "red" lw 2,\
 'RK_isodis_n7_z_1.txt' using 1:2  title " " w line dt'.'  lt rgb "blue" lw 3

  @BMARGIN; @LMARGIN
  @YTICS; @XTICS
  set ytics  0,0.2,1
  set label 1 'N = 4' at graph 0.05,0.1
   set label 2 'z = 10' at graph 0.05,0.3
  plot 'RK_N4_z10.txt' using 1:2  title " " w lines lt rgb "red" lw 2,\
 'RK_isodis_n4_z_10.txt' using 1:2  title " " w line dt'.'  lt rgb "blue" lw 3

 @BMARGIN; @RMARGIN
  @NOYTICS
  set label 1 'N = 7' at graph 0.05,0.1
  plot 'RK_N7_z10.txt' using 1:2  title " " w lines lt rgb "red" lw 2,\
 'RK_isodis_n7_z_10.txt' using 1:2  title " " w line dt'.'  lt rgb "blue" lw 3
  set label 1 'N = 7' at graph 0.05,0.1



EOF



