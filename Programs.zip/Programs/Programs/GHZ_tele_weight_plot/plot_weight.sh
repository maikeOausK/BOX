#!/bin/bash
gnuplot <<- EOF
  set size 1,0.6
  set origin 0,0.35
  set term postscript eps 
  set term post landscape color "Times-Roman" 20
  set output 'weightGHZtele.eps'
  set samples 1000
  set xrange [0:1]
  set yrange [0:1.01]
  set xtics  0,0.2,1
  set ytics  0.0,0.2,1
  set format y "%g"
  set xlabel "{/Symbol W}/V_0"
  set ylabel "F"
  i = {0.0,1.0}
  set multiplot layout 1,2 rowsfirst
  set key samplen 2


## Macros:
  TMARGIN = "set tmargin at screen 0.90; set bmargin at screen 0.55"
  BMARGIN = "set tmargin at screen 0.55; set bmargin at screen 0.20"
  LMARGIN = "set lmargin at screen 0.15; set rmargin at screen 0.55"
  RMARGIN = "set lmargin at screen 0.55; set rmargin at screen 0.95"
# No tics
  NOYTICS = "set format y ''; unset ylabel"
  YTICS = "set format y '%g'; set ylabel 'F'"
  XTICS = "set format x '%g'; set xlabel '{/Symbol W}/V_0'"
  NOXTICS = "set format x ''; unset xlabel"



  @TMARGIN; @LMARGIN
  @YTICS; @NOXTICS 
  @XTICS
  set key at 1,1
  set xtics 0,0.2,0.8
  set label 1 'a' at graph 0.05,0.15
  plot abs((exp(-i*pi/(8*x)))* (cosh(pi*sqrt(-1-16*x*x)/(8*x)) + i*sinh(pi*sqrt(-1-16*x*x)/(8*x))/sqrt(-1-16*x*x)) ) title "|{/Symbol g}|" w lines lt rgb "red" lw 2,\
 'GHZ_3state_scheme.txt' using 1:2  title "N = 4" w line dt'-' lt rgb "blue" lw 3,\
 'GHZ_3state_scheme.txt' using 1:3  title "N = 6" w line dt'.' lt rgb "dark-green" lw 3
 #'GHZ_3state_scheme.txt' using 1:4  title "N = 8" w line dt'..-' lt rgb "magenta" lw 3

  @TMARGIN; @RMARGIN 
  @NOYTICS
  @XTICS
  set key at 1.02,1
  set xtics  0,0.2,1
    set label 1 'b' at graph 0.05,0.15 
  plot  abs((exp(-i*pi/(8*x)))* (cosh(pi*sqrt(-1-16*x*x)/(8*x)) + i*sinh(pi*sqrt(-1-16*x*x)/(8*x))/sqrt(-1-16*x*x)) ) title "|{/Symbol g}'|" w lines lt rgb "red" lw 2,\
 'Fidelity.txt' using 1:4  title "N = 4" w line dt'-' lt rgb "blue" lw 3,\
'Fidelity.txt' using 1:5  title "N = 5" w line dt'.' lt rgb "dark-green" lw 3
#'Fidelity.txt' using 1:6  title "N = 6" w line dt'-' lt rgb "magenta" lw 3


EOF




