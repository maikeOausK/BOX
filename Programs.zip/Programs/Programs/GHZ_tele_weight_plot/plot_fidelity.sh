#!/bin/bash
gnuplot <<- EOF
  set term postscript eps 
  set term post landscape color "Times-Roman" 28
  set yrange [0:1.02]
  set format x '%g'
  set xrange [0:1]
  set xtics 0,0.2,1.2
  set output 'Fidelity_weight.eps'
  set xlabel "{/Symbol W}/V_0"
  set ylabel "F"
  set key at 1., 1.01
  i = {0.0,1.0}

  plot  abs((exp(-i*pi/(8*x)))* (cosh(pi*sqrt(-1-16*x*x)/(8*x)) + i*sinh(pi*sqrt(-1-16*x*x)/(8*x))/sqrt(-1-16*x*x)) ) title "|{/Symbol g}'|" w lines lt rgb "red" lw 2,\
 'Fidelity.txt' using 1:3  title "N = 3" w line dt'.' lt rgb "blue" lw 3,\
'Fidelity.txt' using 1:4  title "N = 4" w line dt'-' lt rgb "dark-green" lw 3

EOF




