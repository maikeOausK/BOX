% Function used to calculate distance between two lattice points 
% in the case of disorder
% Disorder originates from the finite temperature of the lattice system
% 
% used in the program tele_disorder

% V_k = Vo SUM_l (n_k n_l)/|r_k-r_l|

function d_kl = dist(k,l,a,N,sigma_i,delk)
  
% k is the actual lattice site
% l are all other lattice sites
% a lattice spacing
% N nr of atoms in the lattice


x = a*(1:N); % spin chain

%delk = delk*sigma_i;
  delk(2) = delk(2)*sigma_i;
  delk(3) = delk(3)*sigma_i;
 
 dell    = randn(1,3);
% dell = dell*sigma_i;
  dell(2) = dell(2) * sigma_i;
  dell(3) = dell(3) * sigma_i;
  
d_kl = sqrt( ( delk(1)-dell(1))^2  + (delk(2)- dell(2))^2 + (x(k)+delk(3) -(x(l) + dell(3)))^2);

end