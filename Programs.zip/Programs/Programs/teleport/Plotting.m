% Plotting Program 


Disorder4 = dlmread('Fid_dis_iso_N_4.txt');
Disni4 = dlmread('Fid_dis_noniso_N_4.txt');
Fid = dlmread('Fidelity.txt')
% 
figure()
plot(  Disorder4(:,1),Disorder4(:,2), Fid(:,1),Fid(:,4),  Disni4(:,1),Disni4(:,2))
xlabel('\Omega/V_0')
ylabel('Fidelity F')
%legend('no dis.', 'dis')
xlim([0 1])

%
