#!/bin/bash
gnuplot <<- EOF
  set term postscript eps 
  set term post landscape color "Times-Roman" 28
  set output 'weightGHZ.eps'
  set samples 1000
  set xrange [0:1]
  set yrange [0.2:1.01]
  set xtics  0,0.2,1
  set ytics  0.0,0.2,1
  set format y "%g"
  set xlabel "{/Symbol W}/V_0"
  set ylabel "|{/Symbol g}|"
  i = {0.0,1.0}
  plot abs((exp(-i*pi/(8*x)))* (cosh(pi*sqrt(-1-16*x*x)/(8*x)) + i*sinh(pi*sqrt(-1-16*x*x)/(8*x))/sqrt(-1-16*x*x)) ) title "" w lines lt rgb "dark-violet" lw 2
EOF




