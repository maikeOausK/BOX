#!/bin/bash
gnuplot <<- EOF
  set term postscript eps 
  set term post landscape color "Times-Roman" 24
  set output 'disN4.eps'
  set samples 1000 
  set macros
  set xrange [0:1]
  set yrange [0.2:1.01]
  set xtics  0,0.2,1
  set ytics  0,0.2,1
  set format y "%g"
  set ylabel "Fidelity F"
  set xlabel "{/Symbol W}/V_0"

  set label 1 'N = 4' at graph 0.05,0.1
  set label 2 at graph 0.7,0.9 point pointtype 7 pointsize 1 lc rgb 'red'
  set label 3 at graph 0.8,0.9 point pointtype 7 pointsize 3 lc rgb 'blue'
  set object 1 ellipse center 0.9,0.92 size 0.1,0.04 angle 90. front fillstyle solid fc rgb 'dark-green'

  plot 'Fidelity.txt' using 1:2  title "" w lines lt rgb "red" lw 2 , 'Fid_dis_iso_N_4.txt' using 1:2  title "" w lines lt rgb "blue" lw 2,  'Fid_dis_NONiso_N_4.txt' using 1:2  title "" w lines lt rgb "dark-green" lw 2
#
EOF




