#!/bin/bash
gnuplot <<- EOF
  set term postscript eps 
  set term post landscape color "Times-Roman" 24
  set output 'non_iso_dis_3.eps'
  set samples 1000 
  set macros
  set xrange [0:1]
  set yrange [0.2:1.01]
  set xtics  0,0.2,1
  set ytics  0,0.2,1
  set format y "%g"
  set xlabel "{/Symbol W}/V_0"

# Macros:
  TMARGIN = "set tmargin at screen 0.90; set bmargin at screen 0.55"
  BMARGIN = "set tmargin at screen 0.55; set bmargin at screen 0.20"
  LMARGIN = "set lmargin at screen 0.15; set rmargin at screen 0.55"
  RMARGIN = "set lmargin at screen 0.55; set rmargin at screen 0.95"
# No tics
  NOYTICS = "set format y ''; unset ylabel"
  YTICS = "set format y '%g'; set ylabel 'Fidelity F'"
  XTICS = "set format x '%g'; set xlabel '{/Symbol W}/V_0'"
  NOXTICS = "set format x ''; unset xlabel"

#
  plot 'FID_N3.txt' using 1:2  title "" w lines lt rgb "red" lw 2, 'FID_N3_dis.txt' using 1:2  title "" w lines lt rgb "blue" lw 2,\
 'FID_N3_non_isodis.txt' using 1:2  title "" w lines lt rgb "dark-green" lw 2
EOF




