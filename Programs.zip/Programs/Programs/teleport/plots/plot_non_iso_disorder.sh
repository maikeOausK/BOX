#!/bin/bash
gnuplot <<- EOF
  set term postscript eps 
  set term post landscape color "Times-Roman" 24
  set output 'non_iso_dis.eps'
  set multiplot layout 2,2 rowsfirst
  set samples 1000 
  set macros
  set xrange [0:1]
  set yrange [0:1.01]
  set xtics  0,0.2,1
  set ytics  0,0.2,1
  set format y "%g"
  set xlabel "{/Symbol W}/V_0"

# Macros:
  TMARGIN = "set tmargin at screen 0.90; set bmargin at screen 0.55"
  BMARGIN = "set tmargin at screen 0.55; set bmargin at screen 0.20"
  LMARGIN = "set lmargin at screen 0.15; set rmargin at screen 0.55"
  RMARGIN = "set lmargin at screen 0.55; set rmargin at screen 0.95"
# No tics
  NOYTICS = "set format y ''; unset ylabel"
  YTICS = "set format y '%g'; set ylabel 'F'"
  XTICS = "set format x '%g'; set xlabel '{/Symbol W}/V_0'"
  NOXTICS = "set format x ''; unset xlabel"

#
  @TMARGIN; @LMARGIN
  @YTICS; @NOXTICS 
  set ytics  0,0.2,1
  set label 1 'N = 4' at graph 0.05,0.1
  set label 2 at graph 0.8,0.9 point pointtype 7 pointsize 1 lc rgb 'red'
  set object 1 ellipse center 0.9,0.92 size 0.1,0.04 angle 90. front fillstyle solid fc rgb 'blue'
  plot 'Fidelity.txt' using 1:4  title "" w lines lt rgb "red" lw 2, 'Fid_dis_noniso_N_4.txt' using 1:2  title "" w lines lt rgb "blue" lw 2
#
  @TMARGIN; @RMARGIN 
  @NOYTICS
  set label 1 'N = 5' at graph 0.05,0.1
  plot 'Fidelity.txt' using 1:5  title "" w lines lt rgb "red" lw 2, 'Fid_dis_noniso_N_5.txt' using 1:2  title "" w lines lt rgb "blue" lw 2
#
  @BMARGIN; @LMARGIN
  @YTICS; @XTICS
  set ytics  0,0.2,0.8
  set xtics  0,0.2,0.8
  set label 1 'N = 6' at graph 0.05,0.1
  plot 'Fidelity.txt' using 1:6  title "" w lines lt rgb "red" lw 2, 'Fid_dis_noniso_N_6.txt' using 1:2  title "" w lines lt rgb "blue" lw 2
#
  @BMARGIN; @RMARGIN
  @NOYTICS
  set xtics 0,0.2,1 
  set label 1 'N = 7' at graph 0.05,0.1
  plot 'Fidelity.txt' using 1:7  title "" w lines lt rgb "red" lw 2,  'Fid_dis_noniso_N_7.txt' using 1:2  title "" w lines lt rgb "blue" lw 2
  unset multiplot
EOF




