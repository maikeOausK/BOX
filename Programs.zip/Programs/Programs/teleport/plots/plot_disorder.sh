#!/bin/bash
gnuplot <<- EOF
  set term postscript eps 
  set term post landscape color "Times-Roman" 24
  set output 'disVO.eps'
  set multiplot layout 2,2 rowsfirst
  set samples 1000 
  set macros
  set logscale x
  set format x "10^{%T}"
   set xrange [1:100]
  set xtics 1,10,100
  set yrange [0:1.03]
  set xlabel "V_O/{/Symbol W}"
  set ylabel "F"

  set key samplen 3
  set key at 70,0.75 Left width -2.8
  set key spacing 1.25
  

 
# Macros:
   TMARGIN = "set tmargin at screen 0.95; set bmargin at screen 0.6
  BMARGIN = "set tmargin at screen 0.54; set bmargin at screen 0.18"
  LMARGIN = "set lmargin at screen 0.13; set rmargin at screen 0.52"
  RMARGIN = "set lmargin at screen 0.58; set rmargin at screen 0.97"

# No tics
  NOYTICS = "set format y ''; unset ylabel"
  YTICS = "set format y '%g'; set ylabel 'F'"
  XTICS = "set format x '10^{%T}'; set xlabel 'V_0/{/Symbol W}'"
  NOXTICS = "set format x ''; unset xlabel"

#
  @TMARGIN; @LMARGIN
  @YTICS; @NOXTICS 
  set ytics  0,0.2,1
  set label 1 'N = 4' at graph 0.05,0.25
  set label 4 'a' at graph 0.9,0.1

  plot 'Fidelity.txt' using 1:4  title "no dis" w lines lt rgb "red" lw 2 ,\
 'Fid_dis_iso_N_4VO.txt' using 1:2  title "iso" w line dt'.' lt rgb "blue" lw 3,\
  'Fid_dis_noniso_N_4VO.txt' using 1:2  title "aniso" w line dt'-' lt rgb "dark-green" lw 3
 


#
  @TMARGIN; @RMARGIN 
  @NOYTICS
  set label 4 'b' at graph 0.9,0.1
  set label 1 'N = 5' at graph 0.05,0.25
  plot 'Fidelity.txt' using 1:5  title "" w lines lt rgb "red" lw 2,\
'Fid_dis_iso_N_5VO.txt' using 1:2  title "" w line dt'.' lt rgb "blue" lw 3,\
  'Fid_dis_noniso_N_5VO.txt' using 1:2  title "" w line dt'-' lt rgb "dark-green" lw 3

  
  unset label 3
  unset label 2
  unset object 1

#
  @BMARGIN; @LMARGIN
  @YTICS; @XTICS
  set label 4 'c' at graph 0.9,0.1
  set label 1 'N = 6' at graph 0.05,0.25
  plot 'Fidelity.txt' using 1:6  title "" w lines lt rgb "red" lw 2,\
 'Fid_dis_iso_N_6VO.txt' using 1:2  title "" w line dt'.' lt rgb "blue" lw 3,\
  'Fid_dis_noniso_N_6VO.txt' using 1:2  title "" w line dt'-' lt rgb "dark-green" lw 3

#
  @BMARGIN; @RMARGIN
  @NOYTICS
 
  set label 1 'N = 7' at graph 0.05,0.25
  set label 4 'd' at graph 0.9,0.1
  plot 'Fidelity.txt' using 1:7  title "" w lines lt rgb "red" lw 2,\
 'Fid_dis_iso_N_7VO.txt' using 1:2  title "" w line dt'.' lt rgb "blue" lw 3,\
  'Fid_dis_noniso_N_7VO.txt' using 1:2  title "" w line dt'-' lt rgb "dark-green" lw 3

  unset multiplot
EOF




