#!/bin/bash
gnuplot <<- EOF
  set term postscript eps 
  set term post landscape color "Times-Roman" 24
  set output 'GHZ_ISOdis.eps'
  set multiplot layout 2,2 rowsfirst
  set samples 1000 
  set macros
  set xrange [0:1]
  set yrange [0:1.01]
  set xtics  0,0.2,1
  set ytics  0,0.2,1
  set format y "%g"
  set xlabel "{/Symbol W}/V_0"
  set ylabel "F"
# Macros:
  TMARGIN = "set tmargin at screen 0.90; set bmargin at screen 0.55"
  BMARGIN = "set tmargin at screen 0.55; set bmargin at screen 0.20"
  LMARGIN = "set lmargin at screen 0.15; set rmargin at screen 0.55"
  RMARGIN = "set lmargin at screen 0.55; set rmargin at screen 0.95"
# No tics
  NOYTICS = "set format y ''; unset ylabel"
  YTICS = "set format y '%g'; set ylabel 'F'"
  XTICS = "set format x '%g'; set xlabel '{/Symbol W}/V_0'"
  NOXTICS = "set format x ''; unset xlabel"

#
  @TMARGIN; @LMARGIN
  @YTICS; @NOXTICS 
  set ytics  0,0.2,1
  set label 1 'N = 4' at graph 0.05,0.1
  plot 'GHZ_2state_scheme.txt' using 1:2  title "no dis." w lines lt rgb "red" lw 2 , 'iso.' using 1:2  title "" w lines lt rgb "blue" lw 2,\
 'GHZ_nonisodisN_4.txt' using 1:2  title "aniso." w lines lt rgb "dark-green" lw 2
#
  @TMARGIN; @RMARGIN 
  @NOYTICS
  set label 1 'N = 6' at graph 0.05,0.1
  plot 'GHZ_2state_scheme.txt' using 1:3  title "" w lines lt rgb "red" lw 2, 'GHZ_isodisN_6.txt' using 1:2  title "" w lines lt rgb "blue" lw 2,\
'GHZ_nonisodisN_6.txt' using 1:2  title "" w lines lt rgb "dark-green" lw 2

#
  @BMARGIN; @LMARGIN
  @YTICS; @XTICS
  set ytics  0,0.2,0.8
  set xtics  0,0.2,0.8
  set label 1 'N = 8' at graph 0.05,0.1
  plot 'GHZ_2state_scheme.txt' using 1:4  title "" w lines lt rgb "red" lw 2,  'GHZ_isodisN_8.txt' using 1:2  title "" w lines lt rgb "blue" lw 2
#
  @BMARGIN; @RMARGIN
  @NOYTICS
  set xtics 0,0.2,1 
  set label 1 'N = 10' at graph 0.05,0.1
# plot '' using 1:5  title "" w lines lt rgb "red" lw 2, 'GHZ_nonisodisN_8.txt' using 1:2  title "" w lines lt rgb "blue" lw 2
  unset multiplot
EOF




