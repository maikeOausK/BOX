% Function used to calculate distance between two lattice points 
% in the case of disorder
% Disorder originates from the finite temperature of the lattice system
% 
% used in the program tele_disorder

% V_k = Vo SUM_l (n_k n_l)/|r_k-r_l|

function d_kl = dist(k,l,a,N,sigma_i,position)
  
% k is the actual lattice site
% l are all other lattice sites
% a lattice spacing
% N nr of atoms in the lattice


x = a*(1:N); % spin chain
  % dell = dell*sigma_i;
 delkx = position(k,1);%*sigma_i;
 delky = position(k,2)*sigma_i;
 delkz = position(k,3)*sigma_i;
 
 %dell    = randn(1,3);
 dellx = position(l,1);%*sigma_i;
 delly = position(l,2)*sigma_i;
 dellz = position(l,3)*sigma_i;

  
d_kl = sqrt( ( delkx-dellx)^2  + (delky- delly)^2 + (x(k)+delkz -(x(l) + dellz))^2);

end