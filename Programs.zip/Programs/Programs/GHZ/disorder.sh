#!/bin/bash
gnuplot <<- EOF
  set size 1,0.55
  set origin 0,0.4
  set term postscript eps 
  set term post landscape color "Times-Roman" 20
  set output 'GHZdis_VO.eps'
  set macros
  set logscale x
  set format x "10^{%T}"
  set format y "%g"
  set xrange [0.1:1000]
  set xtics 0.01,10,1000
  set yrange [0:1.05]
  set ytics  0,0.2,1

  set multiplot layout 1,2 rowsfirst
  set key samplen 3
    set key at 5,0.99 Left width -2.8
  set key spacing 1.25


## Macros:
  TMARGIN = "set tmargin at screen 0.9; set bmargin at screen 0.55
  BMARGIN = "set tmargin at screen 0.54; set bmargin at screen 0.18"
  LMARGIN = "set lmargin at screen 0.13; set rmargin at screen 0.52"
  RMARGIN = "set lmargin at screen 0.58; set rmargin at screen 0.97"

# No tics
  NOYTICS = "set format y ''; unset ylabel"
  YTICS = "set format y '%g'; set ylabel 'F'"
  XTICS = "set format x '10^{%T}'; set xlabel 'V_0/{/Symbol W}'"
  NOXTICS = "set format x ''; unset xlabel"

#
   @TMARGIN; @LMARGIN
  @YTICS; @NOXTICS 
  @XTICS
  set label 4 'a'  at graph 0.05,0.15
  set ytics  0,0.2,1
  set label 1 'N = 4' at graph 0.6,0.15
  plot 'GHZ_2state_scheme.txt' using 1:2  title "no dis" w lines lt rgb "red" lw 2 ,\
   'GHZ_isodisN_4VO.txt' using 1:2  title "iso " w line dt'.' lt rgb "blue" lw 3,\
   'GHZ_nisodisN_4VO.txt' using 1:2  title "ansio" w line dt'-' lt rgb "dark-green" lw 3
  
  unset label 2
  unset label 3
  unset object 1


#
  @TMARGIN; @RMARGIN 
  @NOYTICS
  @XTICS

  set label 4 'b'  at graph 0.05,0.15
  set label 1 'N = 6' at graph 0.6,0.15
  plot 'GHZ_2state_scheme.txt' using 1:3  title "" w line dt'' lt rgb "red" lw 2,\
 'GHZ_isodisN_6VO.txt' using 1:2  title "" w line dt'.' lt rgb "blue" lw 3,\
 'GHZ_nisodisN_6VO.txt' using 1:2  title "" w line dt'-' lt rgb "dark-green" lw 3

EOF




