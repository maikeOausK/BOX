#!/bin/bash
gnuplot <<- EOF
  set term postscript eps 
  set term post landscape color "Times-Roman" 28
  set output 'GHZ3state.eps'
  set samples 1000 
  set macros
  set xrange [0:1]
  set yrange [0:1.01]
  set xtics  0,0.2,1
  set ytics  0,0.2,1
  set format y "%g"
  set xlabel "{/Symbol W}/V_0"
  set ylabel "F"
  set label 1 '3-level scheme'  at graph 0.65,0.1 

  plot 'GHZ_3state_scheme.txt' using 1:2  title "N = 4" w lines lt rgb "red" lw 2,\
 'GHZ_3state_scheme.txt' using 1:3  title "N = 6" w line dt'-' lt rgb "blue" lw 3,\
 'GHZ_3state_scheme.txt' using 1:4  title "N = 8" w line dt'..-' lt rgb "dark-green" lw 2
EOF




