% Read in data and plot it


% 1: Omega/V_0, 2: N = 4, 3: N = 6
fid_GHZ = dlmread('GHZ_2state_scheme.txt');

isodis4 = dlmread('GHZ_isodisN_4.txt');
nisodis4 = dlmread('GHZ_nonisodisN_4.txt');

isodis6 = dlmread('GHZ_isodisN_6.txt');
nisodis6 = dlmread('GHZ_nonisodisN_6.txt');

% fid_RK = dlmread('RK_N4_z10.txt');
% isodis6 = dlmread('RK_isodis_n4_z_10.txt');
% nisodis6 = dlmread('RK_nonisodis_n4_z_10.txt');

% 
%  figure(1)
%  plot(fid_GHZ(:,1),fid_GHZ(:,2),isodis4(:,1),isodis4(:,2),nisodis4(:,1),nisodis4(:,2))
% 
% figure(2)
% semilogx(fid_GHZ(:,1),fid_GHZ(:,2),'r',1./isodis4(:,1),isodis4(:,2),'b',1./nisodis4(:,1),nisodis4(:,2),'k')
% hold on;
% semilogx(fid_GHZ(:,1),fid_GHZ(:,3),'+m',1./isodis6(:,1),isodis6(:,2),'+c', 1./nisodis6(:,1),nisodis6(:,2),'+g')


% fileID = fopen('FN4_alpha.txt','w');
% fprintf(fileID,'%6.5f %12.11E %12.11E %12.11E \n',...
%     [V_0./Omega_vec;fid(1,:);fid(2,:);fid(3,:)]);
% fclose(fileID);


% 
% fileID = fopen('GHZ_nisodisN_4VO.txt:q
','w');
% fprintf(fileID,'%6.5f %12.11E\n',...
%     [1./nisodis4(:,1);nisodis4(:,2)]);
% fclose(fileID);
% 
% fileID = fopen('GHZ_isodisN_6VO.txt','w');
% fprintf(fileID,'%6.5f %12.11E\n',...
%     [1./isodis6(:,1);isodis6(:,2)]);
% fclose(fileID);
% 
% fileID = fopen('GHZ_nisodisN_6VO.txt','w');
% fprintf(fileID,'%6.5f %12.11E\n',...
%     [1./isodis6(:,1);isodis6(:,2)]);
% fclose(fileID);

