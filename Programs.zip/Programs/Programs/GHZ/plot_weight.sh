#!/bin/bash
gnuplot <<- EOF
  set term postscript eps 
  set term post landscape color "Times-Roman" 28
  set output 'weightGHZ.eps'
  set samples 1000
  set logscale x
  set format x "10^{%T}"
  set format y "%g"
  set xrange [0.1:1000]
  set xtics 0.01,10,1000
  set yrange [0:1.05]
  set ytics  0,0.2,1


  i = {0.0,1.0}
  plot  'FID_N2.txt' using 1:2  title "N = 2" w line dt'-' lt rgb "blue" lw 2,\
   'GHZ_3state_scheme.txt' using 1:2  title "N = 4" w line dt'-' lt rgb "dark-green" lw 2,\
 0.25*abs(1+((exp(-i*pi*x/(8)))* (cos(pi*sqrt(16+x*x)/(8)) + i*x*sin(pi*sqrt(16+x*x)/(8))/sqrt(16+x*x))))**2 title "|{/Symbol g}|" w lines lt rgb "red" lw 2

EOF




