
% Construction of a GHZ state
% GHZ = |+-+-+-...> +|-+-+-+...>
% |+> = spin up
% |-> = spin down
% The initial state: |Psi> = |++++...>
%
% The system is treated as an effective 2 state system
% with the states |R> and |+>  
%(it is assumed that the (pi,-) pulse works perfectly and all occupation
% of the |R> state is transferred to the |-> state => the (pi,-) is neglected
% and in the end, the occupation of |R> can be interpreted as the 
% occupation of the |-> state)

% Hamiltonian of the system:
% H = sum_k Omega_k * sigma_y^(k) + sum_k Delta_k * n_k + sum_k,m V_{km} * n_k * n_m1 

% Omega_k : Rabi frequency of particle k
% Delta_k : Detuning of the rydberg state of particle k
% V_{km}  : interaction potential
% V_km = V_0 * 1/|k-m|^gamma
%Approximation
% Delta_k = 0 -> no Detuning
% H = sum_k Omega_k * sigma_y^(k) + sum_k,m V_{km} * n_k * n_m

clear all;
format long;

N = 4;% nr of atoms in the chain

realisation = 1000;



sigma_i = 0.12; %width of the Gaussian distribution of the atomic position
r0 = 4.1;     % distance between the atoms
    % Definition of the states
ryd  = [1;0]; % Rydberg state
up   = [0;1]; % up state

% single particle operators
num     = ryd*ryd'; % number operator n = |R><R|
sigma_y = [0,i;-i,0]; %
one = eye(2);% identity matrix

% many particle state
gamma = 6; % exponent of interaction force
V_0   =2*pi*8.4;

Omega_vec=[0.001:0.01:1 1.1:0.1:V_0];


fid(length(realisation),length(Omega_vec)) = 0; % Fidelity of the teleportation process
FIDELITY(length(Omega_vec)) = 0;
position(N,3) = 0;


    x = r0*(1:N); % position of the atoms
    
    num_op_m=sparse(N*2^N,2^N);  % all N particle number operators n_k are stored in this matrix
    help_vec_n(1:2,1:2*N) = 0;  % helping vector to produce the N particle sigma_y operator



    O_V(1:length(Omega_vec))       = 0;
    GS = up;
    % Construction of the many particle GS
    for cnt =1:N-1
              GS = kron(GS,up);  %construction of many particle product state
    end

    % Construction of all number operators n_k
    for cnt = 1:N
            % Construction of number operators     
            for cnt2 = 1:N

                 if cnt2 == cnt
                      help_vec_n(:,2*cnt2-1:2*cnt2) = num;
                      continue
                 end
                 help_vec_n(:,2*cnt2-1:2*cnt2) = one;

            end

            n_k = sparse(help_vec_n(:,2*N-1:2*N));

            for cnt3 = N-1:-1:1

              n_k =sparse(kron(help_vec_n(:,2*cnt3-1:2*cnt3),n_k));

            end
            num_op_m((cnt-1)*2^N+1:cnt*2^N,:) = n_k;

    end
    
       %Construction of the correct GHZ state

        GHZ_l = up;
        GHZ_r = ryd;

        for cnt = 1:N-1
          if mod(cnt,2) == 0
              GHZ_l = kron(up,GHZ_l);
              GHZ_r = kron(ryd,GHZ_r);

          else
              GHZ_l = kron(ryd,GHZ_l);
              GHZ_r = kron(up,GHZ_r);
          end
        end

    GHZ = (1/sqrt(2)) * (GHZ_l+GHZ_r);

for counter = 1:length(Omega_vec) % Measuring the fidelity

      for nr = 1:realisation% nr of partivles    

        % Rabi frequency for the two transitions
        Omega = Omega_vec(counter);
        % Interaction potential
        % nearest neighbor interaction

        O_V (counter) = Omega/V_0;

        Psi= GS;
        for cnter = 1:N
              position(cnter,:) = randn(1,3);
        end 
        for k_atom = 1:N

            %Many particle sigma_y_k operator
            help_vec_s(1:2,1:2*N) = 0; %helping vector to produce the N particle sigma_y operator


            for cnt2 = 1:N
                 if cnt2 == k_atom
                      help_vec_s(:,2*cnt2-1:2*cnt2) = sigma_y;
                      continue
                 end
                 help_vec_s(:,2*cnt2-1:2*cnt2) = one;

            end

            s_xk = help_vec_s(:,2*N-1:2*N);

            for cnt3 = N-1:-1:1

              s_xk =sparse(kron(help_vec_s(:,2*cnt3-1:2*cnt3),s_xk));

            end


            % Interaction Potential
            V_int = sparse(2^N,2^N) ;
            Hamil_k = sparse(2^N,2^N);
         
            for cnt = 1:N
              
                if cnt == k_atom 
                    continue
                end
                 d_kl = dist(k_atom,cnt,r0,N,sigma_i,position);
                 V_int = sparse(V_int + 0.5*(V_0*r0^6)/(abs(d_kl)^gamma) * ...
                 num_op_m((k_atom-1)*2^N+1:k_atom*2^N,:)*num_op_m((cnt-1)*2^N+1:cnt*2^N,:)); %* num_all others       
            end
           
            t = pi/(2*Omega);
            Hamil_k = sparse(Omega * s_xk + V_int);
            
            if k_atom == 1
                t = pi/(4*Omega);
            end

            Psi = expm(-1i*t*Hamil_k)*Psi;

        end


       fid(nr,counter) = abs(Psi'*GHZ)^2;
      end
       FIDELITY(counter) = sum(fid(:,counter));
end
 
 figure()
 plot(O_V,FIDELITY(:)/realisation)



fileID = fopen('GHZ_nonisodisN_4.txt','w');
fprintf(fileID,'%6.5f %12.11E\n',[O_V;FIDELITY/realisation]);
fclose(fileID);
